-- Week 4: Sales and Revenue Analysis (MySQL 8+)
-- 1) Create database and table
CREATE DATABASE IF NOT EXISTS week4_sales;
USE week4_sales;

DROP TABLE IF EXISTS sales;
CREATE TABLE sales (
    OrderID VARCHAR(10) PRIMARY KEY,
    OrderDate DATE NOT NULL,
    Region VARCHAR(20) NOT NULL,
    City VARCHAR(40) NOT NULL,
    SalesChannel VARCHAR(20) NOT NULL,
    Product VARCHAR(50) NOT NULL,
    Category VARCHAR(30) NOT NULL,
    Quantity INT NOT NULL,
    UnitPrice DECIMAL(12,2) NOT NULL,
    DiscountPct DECIMAL(5,2) NOT NULL,
    Revenue DECIMAL(14,2) NOT NULL,
    Cost DECIMAL(14,2) NOT NULL,
    Profit DECIMAL(14,2) NOT NULL
);

-- 2) Import sales_data.csv using your SQL tool's Table Data Import Wizard.
-- Match columns to the table above; OrderDate should be DATE.
-- If using MySQL Workbench: right-click table > Table Data Import Wizard.

-- 3) Validation
SELECT COUNT(*) AS total_orders FROM sales;
SELECT * FROM sales LIMIT 10;

-- 4) Required analysis queries
-- Total revenue, cost and profit
SELECT ROUND(SUM(Revenue), 2) AS total_revenue,
       ROUND(SUM(Cost), 2) AS total_cost,
       ROUND(SUM(Profit), 2) AS total_profit
FROM sales;

-- Revenue and profit by region
SELECT Region, ROUND(SUM(Revenue), 2) AS revenue,
       ROUND(SUM(Profit), 2) AS profit
FROM sales
GROUP BY Region
ORDER BY revenue DESC;

-- Best-selling products by quantity
SELECT Product, SUM(Quantity) AS units_sold,
       ROUND(SUM(Revenue), 2) AS revenue
FROM sales
GROUP BY Product
ORDER BY units_sold DESC;

-- Monthly revenue trend
SELECT DATE_FORMAT(OrderDate, '%Y-%m') AS month,
       ROUND(SUM(Revenue), 2) AS revenue,
       ROUND(SUM(Profit), 2) AS profit
FROM sales
GROUP BY DATE_FORMAT(OrderDate, '%Y-%m')
ORDER BY month;

-- Revenue by channel
SELECT SalesChannel, ROUND(SUM(Revenue), 2) AS revenue
FROM sales
GROUP BY SalesChannel
ORDER BY revenue DESC;

-- Category performance and profit margin
SELECT Category,
       ROUND(SUM(Revenue), 2) AS revenue,
       ROUND(SUM(Profit), 2) AS profit,
       ROUND(100 * SUM(Profit) / NULLIF(SUM(Revenue), 0), 2) AS profit_margin_pct
FROM sales
GROUP BY Category
ORDER BY revenue DESC;

-- Check missing values / data quality
SELECT
    SUM(OrderID IS NULL) AS missing_order_id,
    SUM(OrderDate IS NULL) AS missing_order_date,
    SUM(Product IS NULL) AS missing_product,
    SUM(Revenue IS NULL) AS missing_revenue
FROM sales;
