# Week 4 — Sales and Revenue Analysis

This project uses a synthetic practice dataset (200 sales records created for learning; not real company data).

## Files
- `sales_data.csv` — import into SQL and Power BI
- `week4_sales_queries_mysql.sql` — MySQL 8+ schema and analysis queries
- `PowerBI_DAX_Measures.txt` — measures to create in Power BI
- `Submission_Checklist.txt` — final checks and submission items

## Suggested project title
Sales and Revenue Analysis Dashboard — SQL and Power BI

## Workflow
1. Create the `week4_sales` database and `sales` table using the SQL script.
2. Import `sales_data.csv` into the `sales` table.
3. Run all validation and analysis queries; save screenshots of query results.
4. In Power BI Desktop, use Get Data > Text/CSV to import `sales_data.csv` (or connect to MySQL if the connector is available).
5. Create the DAX measures in the measures file.
6. Build the report page and save as `Sales_Revenue_Analysis.pbix`.
7. Export a PDF copy and capture screenshots of SQL results and the dashboard.
8. Submit only through the official internship submission channel and include the repository link if requested.

## Dataset note
The data is synthetic and designed for practice. State this in the report; do not describe it as real business data.
